#Solve SVM problem in the primal
#Using representer theorem to introduce kernels
#The framework is flexible
#1. Classifiers/regressors: multinomial and binary classification are supported
#LS: regression classifier using penalized least squared loss
#Softmax: Softmax classifier using cross entropy loss
#SVM:svm classifier using quadratic hinge loss
#2. Optimization methods:
#BGD: gradient descent (batch)
#NGD: Newton-Raphson optimization (batch)
#CGD: conjugate gradient descent (batch) preconditionned by kernel matrix
#SGD: stochastic gradient descent (under development)
#3. Kernels:
#gaussian: gaussian kernel
#linear: linear kernel
#poly:polynomial kernel

RKHS<-function(Input,Y,
               opType='Classification',classifier='SVM',kernel='linear',
               degree=3,gamm=1,C=1,learning_rate=NULL,tol=1e-2,epochs=400,
               traceObj=F,gradCheck=F,optMode='Newton'){
  t1=Sys.time()
  rsp=transformResponse(Y,classifier,opType)
  resp=rsp$respMat
  X=as.matrix(Input)
  yhat=c()
  betahat=c()
  betahatMat=matrix()
  lossCurve=c()
  KerMat=buildKernel(kernel,X,X,degree=degree,gamm=gamm)
  sv=c()
  
  Ker=KerMat$KerMat
  H=KerMat$H
  S=KerMat$S

  lambd=1/(2*C)

  if(opType=='Regression' & classifier=='LS'){
    inv=solve(t(H)%*%H+lambd*S)
    betahat=inv%*%t(H)%*%resp
  }
  
  if(opType=='Classification'){
    if(optMode=='BGD') out=BGD(X,resp,H,S,classifier,lambd,learning_rate,tol,epochs,traceObj,gradCheck)
    # if(optMode=='SGD') out=SGD(X,resp,H,S,classifier,lambd,tol,epochs,traceObj)
    if(optMode=='NGD') out=NGD(X,resp,Ker,classifier,lambd,tol,epochs)
    # if(optMode=='CGD') out=CGD(X,resp,XTest,resp1,Ker,kerT,H,S,classifier,lambd,tol,epochs)
    
    betahat=out$betahat
    lossCurve=out$lossCurve
    n_iter=out$n_iter
    gradsErr=out$gradsErr
    sv=out$sv
  }
  
  f_x=H%*%betahat
  out=transformOutput(f_x,opType,rsp$CL)
  yhat=out$yhat
  t2=Sys.time()
  modelargs=list(kername=kernel,gamm=gamm,degree=degree,X=X,y=resp,epochs=epochs,
                 lambd=lambd,classes=rsp$CL,opType=opType)
  return(list(yhat=yhat,fx=f_x,yhatMat=out$yhatMat,beta=betahat,sv=sv,rkhsargs=modelargs,
              lossCurve=lossCurve,n_iter=n_iter,gradsErr=gradsErr,duration=t2-t1))
}

# objective<-function(classifier,betahat,kerMat,y,f_x,lambd,eps=1e-8){
#   N=nrow(y)
#   K=ncol(y)
#   obj=0
#   penalty=0
#   if(K==1){
#     if(classifier=='SVM'){
#       idx=1>as.vector(y)*f_x
#       obj=sum((1-y[idx,]*f_x[idx,])^2)
#     }
#     if(classifier=='Softmax'){
#       obj=-mean(y*log(f_x+eps)+(1-y)*log(1-f_x+eps))
#     }
#     penalty=t(betahat)%*%kerMat%*%betahat
#     obj=obj+lambd*penalty
#   }
#   if(K>=3){
#     if(classifier=='SVM'){
#       for(k in 1:K){
#         idx=y[,k]==1
#         vec=as.vector(f_x[idx,k])
#         obj=obj+sum((f_x[idx,-k]+1>vec)*(f_x[idx,-k]+1-vec))
#       }
#     }
#     if(classifier=='Softmax'){
#       obj=-mean(rowSums(y*log(f_x+eps)))
#     }
#     penalty=sum(diag(t(betahat)%*%kerMat%*%betahat))
#     obj=(1/N)*obj+(lambd/2)*penalty
#   }
#   return(obj)
# }

transformResponse<-function(resp,classifier,tt="Classification"){
  classes=NULL
  respMat=matrix()
  if(tt=="Regression") respMat=as.matrix(resp)
  if(tt=="Classification"){
    K=length(unique(resp))
    classes=sort(unique(resp))
    if(K==2 & classifier=="SVM"){
      if(any(resp==0))resp=2*(resp-0.5)
      respMat=as.matrix(resp)
    }
    if(K==2 & classifier=="Softmax"){
      respMat=as.matrix(resp)
      classes=c(0,1)
    } 
    if(K>2){
      respMat=matrix(0,nrow=length(resp),ncol=K)
      classes=sort(unique(resp))
      for (i in 1:length(resp)){respMat[i,which(resp[i]==classes)]=1}
    }
  }
  return(list(respMat=respMat,CL=classes,response=resp))
}

transformOutput<-function(f_x,tt="Regression",classes){
  yhat=c()
  if(tt=="Regression") yhat=f_x
  
  if(tt=="Classification"){
    K=ncol(as.matrix(f_x))
    if(K==1){
      yhat=rep(min(classes),length=nrow(f_x))
      yhat[f_x>0]=max(classes)
    }
    if(K>2){
      yhat=apply(f_x,1,function(x) classes[which.max(x)])
      yhat=as.factor(yhat)
    }
  }
  return(list(yhat=yhat,yhatMat=f_x))
}

softmax<-function(X){
  K=ncol(X)
  if(K>1){
    eps=1e-15
    Eps=1-eps
    M=max(X)
    product=apply(X,2,function(x) exp(-M-log(rowSums(exp(X-M-x)))))
    product=pmax(product,eps)
    product=pmin(product,Eps)
  }
  if(K==1)product=1/(1+exp(-X))
  return(product)
}

# invMat<-function(X,eps=1e-12){
#   eig.X=eigen(X,symmetric = T)
#   P<- eig.X[[2]] 
#   l<- eig.X[[1]] 
#   ind<- l>eps
#   l[ind]<- 1/l[ind] 
#   l[!ind]<- 0
#   ans<-P%*%diag(l,nrow=length(l))%*%t(P)
#   return(ans) 
# }

NGD<-function(X,resp,Ker,classifier,lambd,tol,epochs){
  N=nrow(resp)
  K=ncol(resp)
  sv=rep(TRUE,N)
  betahat=rep(0,N+1)
  if(N>=1000 & classifier=="SVM"){
    N1=N%/%2
    X1=X[1:N1,]
    resp1=as.matrix(resp[1:N1,])
    Ker1=Ker[1:N1,1:N1]
    out=NGD(X1,resp1,Ker1,classifier,lambd,tol,epochs)
    if(classifier=="SVM") sv[1:N1]=out$sv
    if(classifier=="Softmax") betahat[1:N1]=out$betahat
  }
  t=1
  if(classifier=="SVM" & K==1){
    repeat{
      betahat=rep(0,N)
      intercept=0
      Ksv=Ker[sv,sv]
      Ysv=c(0,resp[sv,])
      IntMat=Ksv+lambd*diag(sum(sv))
      IntMat=rbind(1,IntMat)
      IntMat=cbind(1,IntMat)
      IntMat[1,1]=0
      bsv=solve(IntMat)%*%Ysv
      
      intercept=bsv[1]
      betahat[sv]=bsv[-1]
      yhat=Ker%*%betahat+intercept
      sv_new=(resp*yhat) <1
      if(all(sv_new==sv)|t>50) break
      sv=sv_new
      # print(paste(round(as.numeric(obj),3),sum(sv)))
      t=t+1
    }
    betahat=c(intercept,betahat)
  }
  if(classifier=="Softmax" & K==1){
    obj1=0
    H=cbind(1,Ker)
    K1=cbind(0,Ker)
    K1=rbind(0,K1)
    K1[1,1]=1
    I1=cbind(0,diag(N))
    I1=rbind(0,I1)
    I2=rbind(1,diag(N))
    beta_old=betahat
    f_x=H%*%beta_old
    yhat=softmax(f_x)
    grad=2*lambd*I1%*%beta_old+I2%*%(yhat-resp)
    # thd=sum((K1%*%grad)^2)*tol
    repeat{
      grad=2*lambd*I1%*%beta_old+I2%*%(yhat-resp)
      hess=2*lambd*I1+I2%*%diag(c(yhat*(1-yhat)))%*%H
      delt=solve(hess)%*%grad
      beta_new=beta_old-delt
      f_x=H%*%beta_new
      yhat=softmax(f_x)
      t=t+1
      eps=sum(grad*delt)
      beta_old=beta_new
      if(t>15| eps<tol) break
    }
    betahat=beta_new
    sv_new=0
  }
  return(list(betahat=betahat,n_iter=t,sv=sv_new))
}

CGD<-function(X,resp,XT,respT,Ker,kerT,H,S,classifier,lambd,tol,epochs){
  N=nrow(resp)
  K=ncol(resp)
  betahat=c()
  t=1
  K1=cbind(0,Ker)
  K1=rbind(0,K1)
  K1[1,1]=1
  I1=cbind(0,diag(N))
  I1=rbind(0,I1)
  I2=rbind(1,diag(N))
  sv=c()
  loss=c()
  if(classifier=="SVM" & K==1){
    sv=rep(TRUE,N)
    sv1=c()
    I0=diag(sv)
    A=lambd*I1+I2%*%I0%*%H
    b=I2%*%I0%*%resp
    betahat=rep(0,(N+1))
    yhat=H%*%betahat
    d=2*(-A%*%betahat+b)
    g_old=d
    gnorm0=sum((K1%*%g_old)^2)
    thd=tol*gnorm0
    repeat{
      alpha1=t(d)%*%K1
      alpha=as.numeric(alpha1%*%g_old/(alpha1%*%A%*%d))
      betahat=betahat+alpha*d
      yhat=H%*%betahat
      sv1=resp*yhat<1
      I0=diag(c(sv1))
      A=lambd*I1+I2%*%I0%*%H
      b=I2%*%I0%*%resp
      g_new=-A%*%betahat+b
      numerator=as.numeric(t(g_new)%*%K1%*%g_new)
      denumerator=as.numeric(t(g_old)%*%K1%*%g_old)
      d=2*g_new+numerator*d/denumerator
      gnorm1=sum((K1%*%g_new)^2)
      if(t>50 | all(sv==sv1) | gnorm1<thd) break
      t=t+1
      sv=sv1
      g_old=g_new
    }
  }
  if(classifier=="Softmax"& K==1){
    
    betahat=rep(0,(N+1))
    yhat=H%*%betahat
    h_x=softmax(yhat)
    g_old=2*lambd*I1%*%betahat+I2%*%(h_x-resp)
    g_old=-g_old
    d=g_old
    gnorm0=sum((K1%*%g_old)^2)
    thd=tol*gnorm0
    repeat{
      alpha1=t(d)%*%K1
      A=2*lambd*I1+I2%*%diag(c(h_x*(1-h_x)))%*%H
      alpha=as.numeric(alpha1%*%g_old/(alpha1%*%A%*%d))
      betahat=betahat+alpha*d
      yhat=H%*%betahat
      h_x=softmax(yhat)
      g_new=2*lambd*I1%*%betahat+I2%*%(h_x-resp)
      g_new=-g_new
      numerator=as.numeric(t(g_new)%*%K1%*%g_new)
      denumerator=as.numeric(t(g_old)%*%K1%*%g_old)
      d=g_new+numerator*d/denumerator
      gnorm1=sum((K1%*%g_new)^2)
      print(gnorm1)
      if(t>50 | gnorm1<thd) break
      t=t+1
      g_old=g_new
    }
  }
  return(list(betahat=betahat,n_iter=t,gradsErr=c(),lossCurve=loss,sv=sv))
}

buildKernel<-function(ker,X,Z,degree=3,gamm=0.1,pred=FALSE){
  H=c()
  S=c()
  if(ker=='linear') degree=1
  if(ker%in%c('polynomial','linear')) kermat=((Z%*%t(X)+1)^degree)-1
  if(ker=='gaussian') kermat=apply(X,1,function(x) exp(-gamm*rowSums(t(t(Z)-x)^2)))
  if(!pred){
    H=cbind(1,kermat)
    S=cbind(0,kermat)
    S=rbind(0,S)
  }
  return(list(H=H,KerMat=kermat,S=S))
}

# gradChecker<-function(loss,betahat,H,S,y,fx,l,eps=1e-6){
#   I=sample(nrow(betahat),4,replace = F)
#   J=sample(ncol(betahat),2,replace = T)
#   options(digits = 12)
#   error=rep(0,8)
#   for(j in 1:2){
#     for(i in 1:4){
#       betaLeft=betahat
#       betaRight=betahat
#       betaLeft[I[i],J[j]]=betahat[I[i],J[j]]-eps
#       fx_left=H%*%betaLeft
#       betaRight[I[i],J[j]]=betahat[I[i],J[j]]+eps
#       fx_right=H%*%betaRight
#       objLeft=objective(loss,betaLeft,S,y,fx_left,l)
#       objRight=objective(loss,betaRight,S,y,fx_right,l)
#       numGrad=(objRight-objLeft)/(2*eps)
#       analGrad=computeGrad(loss,y,fx,H,S,l,betahat)
#       analGrad_ij=analGrad[I[i],J[j]]
#       error[(j-1)*4+i]=(analGrad_ij-numGrad)/max(abs(analGrad_ij),abs(numGrad))
#     }
#   }
#   return(error)
# }

# BGD<-function(X,y,H,S,ll,lambd=0.05,lr=NULL,tol=1e-8,ep=200,traceObj=F,gradCheck=F){
#   K=ncol(y)
#   N=nrow(X)
#   lossCurve=c()
#   n_iter=1
#   gradsErr=c()
#   if(K==1){ #binary classification
#     betahat=matrix(0,nrow=N+1,ncol=1)
#     sv=sample(c(TRUE,FALSE),N,replace = T)
#     #betahat=matrix(runif(N+1),ncol=1)
#     repeat{
#       if(is.null(lr)) lr=1/n_iter
#       
#       out=updateParams(ll,y,H,S,lambd,betahat)
#       betahat_new=out$betahat_new
#       sv_new=out$sv_new
#       # if(sum(sv_new)>1) grad=-as.matrix(colSums(as.matrix(y[sv_new,]*H[sv_new,])))
#       # if(sum(sv_new)==1) grad=-y[sv_new]*H[sv_new,]
#       # gradMat=(1/N)*grad+lambd*S%*%betahat
#       # betahat_new=betahat-lr*gradMat
#       
#       if(traceObj){
#         lossCurve=c(lossCurve,objective(ll,betahat,S,y,f_x,lambd))
#       }
#       
#       if(all(sv==sv_new)) break
#       # if(sqrt(sum(grad[-1,]^2))<1e-3*N*n_iter) break
#       
#       if(n_iter%in%c(200,800,1000) & gradCheck){
#         gradsErr=rbind(gradsErr,t(gradChecker(ll,betahat,H,S,y,f_x,lambd)))
#       }
#       betahat=betahat_new
#       sv=sv_new
#       n_iter=n_iter+1
#     }
#   }
#   if(K>=3){
#     betahatMat=matrix(0,ncol=K,nrow=(N+1))
#     repeat{
#       if(is.null(lr)) lr=1/n_iter
#       f_x=as.matrix(H%*%betahatMat)
#       gradMat=computeGrad(ll,y,f_x,H,S,lambd,betahatMat)
#       betahatMat_new=betahatMat-lr*gradMat
#       if(traceObj){
#         lossCurve=c(lossCurve,objective(ll,betahatMat,S,y,f_x,lambd))
#       }
#       if(n_iter>ep) break
#       
#       if(n_iter%in%c(200,800,1000) & gradCheck){
#         gradsErr=rbind(gradsErr,t(gradChecker(ll,betahatMat,H,S,y,f_x,lambd)))
#       }
#       betahatMat=betahatMat_new
#       n_iter=n_iter+1
#     }
#     betahat=betahatMat
#   }
#   return(list(beta=betahat,sv=sv,lossCurve=lossCurve,n_iter=n_iter,gradsErr=gradsErr))
# }

# SGD<-function(X,y,H,S,ll,lambd=0.05,tol=1e-8,ep=200,traceObj=F){
#   K=ncol(y)
#   N=nrow(X)
#   lossCurve=c()
#   n_iter=1
#   gradsErr=c()
#   if(K==1) betahat=matrix(0,nrow=N+1,ncol=1)
#   if(K>1) betahat=matrix(0,ncol=K,nrow=(N+1))
#   for(t in 1:ep){
#     i=sample(1:N,1)
#     lr_t=1/(lambd*t)
#     fx_i=H[i,]%*%betahat
#     grad=lambd*S%*%betahat
#     if(K==1 & (y[i,1]*fx_i<1) & ll=='hingeLoss') grad=grad-y[i,1]*H[i,]
#     #if(K==1 & (lr_t*y[i,1]*fx_t<1) & ll=='hingeLoss') betahat[i,1]=betahat[i,1]+1
#     if(K>1 & sum(fx_i[-which(y[i,]==1)]+1>fx_i[which(y[i,]==1)])>0 & ll=='hingeLoss'){
#       k=which(y[i,]==1)
#       s=sum(fx_i[-k]+1>fx_i[k])
#       grad[,-k]=grad[,-k]+matrix(rep(H[i,],(K-1)),ncol=K-1)
#       grad[,k]=grad[,k]-s*H[i,]
#     }
#     betahat=betahat-lr_t*grad
#     
#   }
#   return(list(beta=betahat,lossCurve=lossCurve,n_iter=n_iter,gradsErr=gradsErr))
# }

# pegasos<-function(Input,y,lambd,epochs){
#   p=ncol(Input)
#   X=as.matrix(cbind(1,Input))
#   N=nrow(X)
#   betahat=rep(0,p+1)
#   yhat=c()
#   for(t in 1:epochs){
#     i=sample(1:N,1)
#     lr=1/(lambd*t)
#     fx_i=sum(X[i,]*betahat)
#     grad=lambd*c(0,betahat[-1])
#     if(y[i]*fx_i<1) grad=grad-y[i]*X[i,]
#     betahat=betahat-lr*grad
#   }
#   fx=X%*%betahat
#   yhat=rep(-1,N)
#   yhat[fx>0]=1
#   return(list(yhat=yhat,betahat=betahat))
# }

predictRkhs<-function(Input,rkhs){
  X=as.matrix(Input)
  gamm=rkhs$rkhsargs$gamm
  degree=rkhs$rkhsargs$degree
  Xtrain=rkhs$rkhsargs$X
  y=rkhs$rkhsargs$y
  epochs=rkhs$rkhsargs$epochs
  kerName=rkhs$rkhsargs$kername
  lambd=rkhs$rkhsargs$lambd
  out=buildKernel(kerName,Xtrain,X,degree,gamm,pred=TRUE)
  Ker=out$KerMat
  alphahat=rkhs$beta
  beta0=alphahat[1]
  fx=beta0+Ker%*%as.matrix(alphahat[-1])
  opType=rkhs$rkhsargs$opType
  CL=rkhs$rkhsargs$classes
  out=transformOutput(fx,opType,CL)
  yhat=out$yhat
  return(yhat)
}
